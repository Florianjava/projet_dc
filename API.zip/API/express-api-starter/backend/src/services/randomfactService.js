const randomfactAPI = async (path) => {
    try {
        const response = await fetch(`https://uselessfacts.jsph.pl/api/${path}`);
        return response.json();
    }
    catch (error) {
        throw new Error('Useless facts API request failed', error);
    }
};
export const getRandomFact = () => {
    return randomfactAPI('v2/facts/random');
};

export const getTodayFact = () => {
    return randomfactAPI('v2/fact/today');
};