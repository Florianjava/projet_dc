import express from 'express';
import logger from 'pino-http';
//import languagesRoute from './routes/languages.js';
//import projectsRoute from './routes/projects.js';
import randomfactsRoute from './routes/randomfact.js';
import todayfactsRoute from './routes/todayfact.js';


const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(logger({ level: process.env.NODE_ENV === 'test' ? 'error' : 'info' }));


//app.use('/api/v1/languages', languagesRoute);
//app.use('/api/v1/projects', projectsRoute);
app.use('/api/v1/randomfact', randomfactsRoute)
app.use('/api/v1/todayfact', todayfactsRoute)


export default app;
