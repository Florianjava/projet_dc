import { Router } from 'express';
import { getTodayFact } from '../services/randomfactService.js';

const router = Router();

router.get('/', async (req, res) => {
  const fact = await getTodayFact();

  res.json(fact);
});



export default router;