import { Router } from 'express';
import { getRandomFact } from '../services/randomfactService.js';

const router = Router();

router.get('/', async (req, res) => {
  const result = await getRandomFact();
  console.log(result);

  res.json(result);
});



export default router;